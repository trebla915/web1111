// /Users/albertborrego/1111/frontend/app/RootLayout.tsx

// Import 'react-native-get-random-values' at the very top
import 'react-native-get-random-values'; // Essential for UUID generation

import React, { useEffect, useState } from 'react';
import { Slot, useRouter } from 'expo-router';
import { AuthProvider, useAuth } from '../src/contexts/AuthContext';
import { UserProvider } from '../src/contexts/UserContext';
import { View, ActivityIndicator, StyleSheet } from 'react-native';
import * as SplashScreen from 'expo-splash-screen';
import { Provider as PaperProvider } from 'react-native-paper';

// Prevent the splash screen from auto-hiding
SplashScreen.preventAutoHideAsync();

const AppContent: React.FC = () => {
  const router = useRouter();
  const { firebaseUser, isLoading } = useAuth();
  const [appReady, setAppReady] = useState(false);

  useEffect(() => {
    const prepareApp = async () => {
      try {
        console.log('Preparing app...');
        // Simulate additional setup tasks if needed
        setAppReady(true);
      } catch (error) {
        console.error('App preparation error:', error);
      }
    };
    prepareApp();
  }, []);

  useEffect(() => {
    const handleNavigation = async () => {
      if (!appReady || isLoading) return;

      await SplashScreen.hideAsync();

      if (firebaseUser) {
        // Avoid redundant logs for repetitive navigations
        console.log('Navigating to /tabs...');
        router.replace('/(tabs)');
      } else {
        console.log('Navigating to /auth/Login...');
        router.replace('/(auth)/Login');
      }
    };

    handleNavigation();
  }, [appReady, isLoading, firebaseUser, router]);

  return null; // Slot is managed by RootLayout
};

export default function RootLayout() {
  return (
    <PaperProvider>
      <AuthProvider>
        <UserProvider>
          <Slot />
          <AppContent />
        </UserProvider>
      </AuthProvider>
    </PaperProvider>
  );
}

const styles = StyleSheet.create({
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff',
  },
});
