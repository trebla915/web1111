import React, { useEffect, useState } from 'react';
import { Stack } from 'expo-router';
import { View, ActivityIndicator, TouchableOpacity, Text, StyleSheet } from 'react-native';
import { useRouter } from 'expo-router';
import { useAuth } from '../../src/contexts/AuthContext';
import { useUser } from '../../src/contexts/UserContext';
import * as SplashScreen from 'expo-splash-screen';

SplashScreen.preventAutoHideAsync(); // Prevent the splash screen from auto-hiding

export default function ReservationsLayout() {
  const router = useRouter();
  const { firebaseUser, isLoading } = useAuth();
  const [appReady, setAppReady] = useState(false);

  useEffect(() => {
    const prepareApp = async () => {
      try {
        console.log('Preparing app...');
        setAppReady(true);
      } catch (error) {
        console.error('App preparation error:', error);
      }
    };
    prepareApp();
  }, []);

  useEffect(() => {
    const handleNavigation = async () => {
      if (!appReady || isLoading) return;

      await SplashScreen.hideAsync();

      if (firebaseUser) {
        console.log('Navigating to Table Selection...');
      } else {
        console.log('Navigating to /auth/Login...');
        router.replace('/(auth)/Login');
      }
    };

    handleNavigation();
  }, [appReady, isLoading, firebaseUser, router]);

  if (isLoading || !appReady) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#ffffff" />
      </View>
    );
  }

  return (
    <Stack
      screenOptions={{
        headerStyle: {
          backgroundColor: '#1c1c1c', // Dark header background for consistency
        },
        headerTintColor: '#ffffff', // White header text
        headerTitleStyle: {
          fontWeight: 'bold',
        },
        headerRight: () => (
          <TouchableOpacity
            onPress={() => router.replace('/')}
            style={styles.homeButton}
          >
            <Text style={styles.homeButtonText}>Home</Text>
          </TouchableOpacity>
        ),
      }}
    >
      <Stack.Screen
        name="TableSelection"
        options={{ title: 'Table Selection' }}
      />
      <Stack.Screen
        name="ReservationModal"
        options={{ title: 'Reservation Details' }}
      />
      <Stack.Screen
        name="PaymentScreen"
        options={{ title: 'Payment' }}
      />
      <Stack.Screen
        name="SummaryScreen"
        options={{ title: 'Summary' }}
      />
    </Stack>
  );
}

const styles = StyleSheet.create({
  homeButton: {
    marginRight: 16,
    padding: 8,
    backgroundColor: '#ffffff',
    borderRadius: 4,
  },
  homeButtonText: {
    color: '#1c1c1c',
    fontWeight: '600',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#000',
  },
});
