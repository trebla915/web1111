import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { useRouter, useLocalSearchParams } from 'expo-router';

export default function SummaryScreen() {
  const router = useRouter();
  const { eventTitle, eventDate, tableNumber, guestCount } = useLocalSearchParams<{
    eventTitle: string;
    eventDate: string;
    tableNumber: string;
    guestCount: string;
  }>();

  const handleReturnHome = () => {
    router.push('/(tabs)'); // Adjust the path to match your home screen
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Reservation Summary</Text>
      <View style={styles.detailContainer}>
        {/* Display reservation details here */}
        <Text style={styles.detailText}>Event: {eventTitle}</Text>
        <Text style={styles.detailText}>Date: {eventDate}</Text>
        <Text style={styles.detailText}>Table: {tableNumber}</Text>
        <Text style={styles.detailText}>Guests: {guestCount}</Text>
        <Text style={styles.detailText}>Deposit: £100.00 (Placeholder)</Text>
        <Text style={styles.detailText}>Total: £475.00 (Placeholder)</Text>
        <Text style={styles.detailText}>Payment: via Stripe (Placeholder)</Text>
      </View>
      <TouchableOpacity style={styles.returnButton} onPress={handleReturnHome}>
        <Text style={styles.buttonText}>Return to Home</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  title: {
    fontSize: 24,
    color: '#fff',
    marginBottom: 20,
  },
  detailContainer: {
    width: '80%',
    backgroundColor: '#333',
    padding: 15,
    borderRadius: 8,
    marginBottom: 20,
  },
  detailText: {
    color: '#fff',
    fontSize: 16,
    marginBottom: 10,
  },
  returnButton: {
    backgroundColor: '#fff',
    padding: 15,
    borderRadius: 8,
    width: '80%',
    alignItems: 'center',
  },
  buttonText: {
    color: '#000',
    fontSize: 16,
    fontWeight: 'bold',
  },
});
