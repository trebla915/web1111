import React, { useState, useCallback } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  ActivityIndicator,
  Alert,
  Image,
  Dimensions,
} from 'react-native';
import { useLocalSearchParams, useRouter, useFocusEffect } from 'expo-router';
import { fetchTablesForEvent } from '../../src/utils/api';
import { useUser } from '../../src/contexts/UserContext';
import { FrontendTable } from '../../src/utils/types';
import ClubLayout from './ClubLayout';

const TableSelection: React.FC = () => {
  const router = useRouter();
  const { setReservationDetails } = useUser();
  const { eventId, eventTitle, eventDate } = useLocalSearchParams<{
    eventId: string;
    eventTitle: string;
    eventDate: string;
  }>();

  const [tables, setTables] = useState<FrontendTable[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const fetchTables = useCallback(async () => {
    try {
      setLoading(true);
      const fetchedTables = await fetchTablesForEvent(eventId);
      if (fetchedTables.length === 0) {
        throw new Error('No tables available for this event');
      }

      console.log('Fetched tables:', fetchedTables);
      setTables(fetchedTables);
      setError(null);
    } catch (err) {
      console.error('Failed to fetch tables:', err);
      setError('Failed to fetch tables. Please try again or select another event.');
      Alert.alert('Error', 'Unable to load tables. Please try again.', [
        { text: 'OK', onPress: () => router.replace('/events') },
      ]);
    } finally {
      setLoading(false);
    }
  }, [eventId]);

  useFocusEffect(
    useCallback(() => {
      if (eventId) {
        fetchTables();
      }
    }, [eventId, fetchTables])
  );

  const handleTableSelection = (tableId: string) => {
    if (!eventId) {
      Alert.alert('Error', 'Event details are missing. Please start over.');
      return;
    }

    const selectedTable = tables.find((table) => table.id === tableId);
    if (!selectedTable) {
      console.error('Table not found for the given tableId:', tableId);
      Alert.alert('Error', 'Table not found. Please try selecting another table.');
      return;
    }

    console.log('[handleTableSelection] Selected table:', selectedTable);

    setReservationDetails({
      eventId: eventId,
      tableId: selectedTable.id,
      tableNumber: selectedTable.number,
      guestCount: 1,
    });

    // Navigate to reservation modal with additional parameters
    router.push({
      pathname: '/reservations/ReservationModal',
      params: {
        eventTitle,
        eventDate,
        tableId: selectedTable.id,
        tableNumber: selectedTable.number,
      },
    });
  };

  if (loading) {
    return (
      <View style={styles.container}>
        <ActivityIndicator size="large" color="#6200ea" />
        <Text style={styles.loadingText}>Loading tables...</Text>
      </View>
    );
  }

  if (error) {
    return (
      <View style={styles.container}>
        <Text style={styles.errorText}>{error}</Text>
        <TouchableOpacity style={styles.retryButton} onPress={() => router.replace('/events')}>
          <Text style={styles.retryButtonText}>Back to Events</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {/* Event Image */}
      <Image
        source={{ uri: 'https://via.placeholder.com/800x400' }} // Replace with your event image URL
        style={styles.eventImage}
        resizeMode="cover"
      />

      {/* Event Details */}
      <View style={styles.eventDetailsContainer}>
        <Text style={styles.eventTitle}>{eventTitle}</Text>
        {eventDate && (
          <Text style={styles.eventDate}>
            Date: {new Date(eventDate).toLocaleDateString()}
          </Text>
        )}
      </View>

      {/* Club Layout for Table Selection */}
      <ClubLayout tables={tables} onTableSelect={(tableId) => handleTableSelection(tableId)} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#121212',
    padding: 10,
    justifyContent: 'flex-start',
  },
  eventImage: {
    width: Dimensions.get('window').width - 20,
    height: 200,
    borderRadius: 10,
    marginBottom: 10,
    alignSelf: 'center',
  },
  eventDetailsContainer: {
    marginBottom: 10,
    paddingHorizontal: 10,
  },
  eventTitle: {
    color: '#fff',
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  eventDate: {
    color: '#aaa',
    fontSize: 16,
    textAlign: 'center',
    marginVertical: 5,
  },
  loadingText: {
    color: '#fff',
    marginTop: 10,
  },
  errorText: {
    color: 'red',
    textAlign: 'center',
    marginBottom: 20,
  },
  retryButton: {
    backgroundColor: '#6200ea',
    padding: 10,
    borderRadius: 5,
  },
  retryButtonText: {
    color: '#fff',
    fontWeight: 'bold',
  },
});

export default TableSelection;
