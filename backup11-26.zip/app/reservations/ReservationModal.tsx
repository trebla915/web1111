import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Alert,
  Image,
} from 'react-native';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { useUser } from '../../src/contexts/UserContext';

export default function ReservationModal() {
  const router = useRouter();
  const { reservationDetails, setReservationDetails } = useUser();
  const { eventTitle, eventDate, tableId, tableNumber } = useLocalSearchParams<{
    eventTitle: string;
    eventDate: string;
    tableId: string;
    tableNumber: string;
  }>();

  const [guestCount, setGuestCount] = useState<number>(
    reservationDetails?.guestCount || 1
  );

  useEffect(() => {
    if (!eventTitle || !tableId) {
      Alert.alert(
        'Error',
        'Missing reservation details. Redirecting to events.',
        [{ text: 'OK', onPress: () => router.replace('/events') }]
      );
    }
  }, [eventTitle, tableId, router]);

  const handleConfirm = () => {
    if (!tableId || !reservationDetails) {
      Alert.alert('Error', 'Reservation details are incomplete.');
      return;
    }

    const maxCapacity = 6; // Assuming max capacity is 6
    if (guestCount <= 0 || guestCount > maxCapacity) {
      Alert.alert(
        'Invalid Input',
        `Number of guests must be between 1 and ${maxCapacity}.`
      );
      return;
    }

    // Update the reservation details in UserContext
    setReservationDetails({
      ...reservationDetails,
      eventId: reservationDetails.eventId,
      guestCount: guestCount,
      tableId: tableId,
      tableNumber: parseInt(tableNumber, 10), // Convert tableNumber to a number type
    });

    // Navigate to Payment Screen with all details
    router.push({
      pathname: '/reservations/PaymentScreen',
      params: {
        eventTitle,
        eventDate,
        tableNumber,
        guestCount,
      },
    });
  };

  const incrementGuestCount = () => {
    setGuestCount((prevCount) => Math.min(prevCount + 1, 6));
  };

  const decrementGuestCount = () => {
    setGuestCount((prevCount) => Math.max(prevCount - 1, 1));
  };

  return (
    <View style={styles.container}>
      {/* Image Section */}
      <Image
        source={{ uri: 'https://via.placeholder.com/600x300' }} // Replace with actual image URL
        style={styles.eventImage}
        resizeMode="cover"
      />

      {/* Event Details */}
      <View style={styles.detailsContainer}>
        <Text style={styles.eventTitle}>{eventTitle}</Text>
        <Text style={styles.eventDate}>{eventDate}</Text>
      </View>

      {/* Table Details */}
      <View style={styles.tableDetailsContainer}>
        <Text style={styles.tableTitle}>{tableNumber ? `Table ${tableNumber}` : 'Selected Table'}</Text>
        <Text style={styles.priceText}>£300.00</Text>
        <Text style={styles.capacityText}>Up to 6 guests</Text>
      </View>

      {/* Guest Count Selection */}
      <View style={styles.guestCountContainer}>
        <Text style={styles.guestLabel}>How many people?</Text>
        <View style={styles.guestCountButtons}>
          <TouchableOpacity
            style={styles.guestButton}
            onPress={decrementGuestCount}
          >
            <Text style={styles.guestButtonText}>-</Text>
          </TouchableOpacity>
          <Text style={styles.guestCount}>{guestCount}</Text>
          <TouchableOpacity
            style={styles.guestButton}
            onPress={incrementGuestCount}
          >
            <Text style={styles.guestButtonText}>+</Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* Total Section */}
      <Text style={styles.totalText}>Total: £475.00</Text>

      {/* Proceed to Payment Button */}
      <TouchableOpacity
        style={styles.button}
        onPress={handleConfirm}
        accessibilityLabel="Confirm the reservation and proceed to payment"
        accessible
      >
        <Text style={styles.buttonText}>Reserve Table</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
    padding: 20,
  },
  eventImage: {
    width: '100%',
    height: 200,
    marginBottom: 20,
  },
  detailsContainer: {
    alignItems: 'center',
    marginBottom: 20,
  },
  eventTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#fff',
  },
  eventDate: {
    fontSize: 16,
    color: '#aaa',
  },
  tableDetailsContainer: {
    backgroundColor: '#1c1c1c',
    padding: 15,
    borderRadius: 10,
    marginBottom: 20,
  },
  tableTitle: {
    fontSize: 20,
    color: '#fff',
    fontWeight: 'bold',
    marginBottom: 5,
  },
  priceText: {
    fontSize: 18,
    color: '#fff',
    marginBottom: 5,
  },
  capacityText: {
    fontSize: 14,
    color: '#aaa',
  },
  guestCountContainer: {
    marginBottom: 20,
    alignItems: 'center',
  },
  guestLabel: {
    fontSize: 18,
    color: '#fff',
    marginBottom: 10,
  },
  guestCountButtons: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  guestButton: {
    backgroundColor: '#444',
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    marginHorizontal: 10,
  },
  guestButtonText: {
    color: '#fff',
    fontSize: 20,
    fontWeight: 'bold',
  },
  guestCount: {
    fontSize: 24,
    color: '#fff',
  },
  totalText: {
    fontSize: 22,
    color: '#fff',
    textAlign: 'center',
    marginBottom: 20,
  },
  button: {
    backgroundColor: '#444',
    padding: 15,
    borderRadius: 8,
    alignItems: 'center',
  },
  buttonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
});
