import React, { useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Alert,
  ActivityIndicator,
} from 'react-native';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { useUser } from '../../src/contexts/UserContext';
import { createReservation } from '../../src/utils/reservations';

export default function PaymentScreen() {
  const router = useRouter();
  const { reservationDetails, userData, isLoading } = useUser();
  const { eventTitle, eventDate } = useLocalSearchParams<{
    eventTitle: string;
    eventDate: string;
  }>();

  useEffect(() => {
    if (isLoading) return;

    if (
      !reservationDetails?.eventId ||
      !reservationDetails?.tableId ||
      !reservationDetails?.guestCount
    ) {
      console.log('Missing reservation details:', reservationDetails);
      Alert.alert('Error', 'Incomplete reservation details. Redirecting to events.', [
        { text: 'OK', onPress: () => router.replace('/events') },
      ]);
    }

    if (!userData) {
      console.error('User data is missing, redirecting to login.');
      console.log('User data:', userData);
      Alert.alert('Error', 'User data is missing. Please log in again.', [
        { text: 'OK', onPress: () => router.replace('/events') },
      ]);
    }
  }, [reservationDetails, userData, isLoading, router]);

  const handlePayment = async () => {
    if (isLoading) {
      Alert.alert('Loading', 'Please wait until user data is loaded.');
      return;
    }

    if (!reservationDetails || !userData || reservationDetails.tableNumber === undefined) {
      console.error('Missing reservation details or user data:', {
        reservationDetails,
        userData,
      });
      Alert.alert('Error', 'Missing reservation details or user data.');
      return;
    }

    try {
      console.log('Starting reservation creation with data:', {
        eventId: reservationDetails.eventId,
        tableId: reservationDetails.tableId,
        tableNumber: reservationDetails.tableNumber,
        userId: userData.id,
        guestCount: reservationDetails.guestCount,
        reservationTime: new Date().toISOString(),
      });

      const reservationResponse = await createReservation(reservationDetails.eventId, {
        eventId: reservationDetails.eventId,
        tableId: reservationDetails.tableId,
        tableNumber: reservationDetails.tableNumber,
        userId: userData.id,
        guestCount: reservationDetails.guestCount,
        reservationTime: new Date().toISOString(),
      });

      console.log('Reservation created successfully:', reservationResponse);

      router.push({
        pathname: '/reservations/SummaryScreen',
        params: {
          eventTitle,
          eventDate,
          tableNumber: reservationDetails.tableNumber,
          guestCount: reservationDetails.guestCount,
        },
      });
    } catch (error) {
      console.error('Failed to complete reservation:', error);
      Alert.alert('Error', 'Failed to complete reservation. Please try again.');
    }
  };

  if (isLoading) {
    return (
      <View style={styles.container}>
        <ActivityIndicator size="large" color="#fff" />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Reservation Details</Text>
      <View style={styles.detailContainer}>
        <Text style={styles.detailText}>Event: {eventTitle}</Text>
        <Text style={styles.detailText}>Date: {eventDate}</Text>
        <Text style={styles.detailText}>
          Table: {reservationDetails?.tableNumber || reservationDetails?.tableId}
        </Text>
        <Text style={styles.detailText}>Guests: {reservationDetails?.guestCount}</Text>
      </View>
      <TouchableOpacity style={styles.paymentButton} onPress={handlePayment}>
        <Text style={styles.buttonText}>Complete Payment</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  title: {
    fontSize: 24,
    color: '#fff',
    marginBottom: 20,
  },
  detailContainer: {
    width: '80%',
    backgroundColor: '#333',
    padding: 15,
    borderRadius: 8,
    marginBottom: 20,
  },
  detailText: {
    color: '#fff',
    fontSize: 16,
    marginBottom: 10,
  },
  paymentButton: {
    backgroundColor: '#fff',
    padding: 15,
    borderRadius: 8,
    width: '80%',
    alignItems: 'center',
  },
  buttonText: {
    color: '#000',
    fontSize: 16,
  },
});
