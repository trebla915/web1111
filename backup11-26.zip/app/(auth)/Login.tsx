import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  ActivityIndicator,
  Alert,
  Image,
  useWindowDimensions,
} from 'react-native';
import { useRouter } from 'expo-router';
import { useAuth } from '../../src/contexts/AuthContext';
import CustomButton from '../../src/components/CustomButton';
import logo from '../../src/assets/logo.png'; // Correct import for logo

const LoginScreen: React.FC = () => {
  const [email, setEmail] = useState<string>('');
  const [password, setPassword] = useState<string>('');
  const { height, width } = useWindowDimensions(); // Responsive handling using dimensions
  const router = useRouter();
  const { signIn, isLoading } = useAuth();

  // Handler for Login
  const handleLogin = async () => {
    if (!email || !isValidEmail(email)) {
      Alert.alert('Invalid Email', 'Please enter a valid email address.');
      return;
    }

    if (!password) {
      Alert.alert('Invalid Password', 'Please enter your password.');
      return;
    }

    try {
      await signIn(email, password);
      setEmail('');
      setPassword('');
      router.push('/'); // Redirect to home screen
    } catch (error: any) {
      console.error('Login Failed:', error);
      Alert.alert('Login Failed', getErrorMessage(error.code));
    }
  };

  // Email Validation
  const isValidEmail = (email: string): boolean => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);

  // Error Message Mapping
  const getErrorMessage = (errorCode: string) => {
    switch (errorCode) {
      case 'auth/user-not-found':
        return 'No account found with this email. Please sign up first.';
      case 'auth/wrong-password':
        return 'Incorrect password. Please try again.';
      case 'auth/invalid-email':
        return 'Invalid email format. Please check and try again.';
      case 'auth/network-request-failed':
        return 'Network error. Please check your connection and try again.';
      default:
        return 'An unexpected error occurred. Please try again.';
    }
  };

  return (
    <View style={styles.container}>
      {/* Logo Section */}
      <View style={styles.logoContainer}>
        <Image
          source={logo}
          style={[
            styles.logo,
            { width: width * 0.8, height: height * 0.25 }, // Making the logo much larger and responsive
          ]}
        />
      </View>

      {isLoading ? (
        <ActivityIndicator size="large" color="#ffffff" />
      ) : (
        <View style={styles.form}>
          {/* Email Input */}
          <TextInput
            placeholder="Enter your email"
            value={email}
            onChangeText={setEmail}
            style={styles.input}
            keyboardType="email-address"
            autoCapitalize="none"
            autoComplete="email"
            placeholderTextColor="#888"
          />

          {/* Password Input */}
          <TextInput
            placeholder="Enter your password"
            value={password}
            onChangeText={setPassword}
            secureTextEntry
            style={styles.input}
            autoComplete="password"
            placeholderTextColor="#888"
          />

          {/* Login Button */}
          <CustomButton
            title="Login"
            onPress={handleLogin}
            outlined={true}
            disabled={isLoading}
            buttonStyle={{
              paddingVertical: 15,
              width: '100%', // Full-width button to align with Sign Up
              borderRadius: 10,
              marginBottom: 15,
              alignItems: 'center',
              borderColor: '#fff', // White border to match input fields
              borderWidth: 1,
              backgroundColor: 'transparent', // Transparent to match the theme
            }}
            textStyle={{
              color: '#ffffff',
              fontSize: 18,
              textAlign: 'center', // Ensure text is centered
              fontWeight: 'bold',
            }}
          />

          {/* Sign Up Button */}
          <CustomButton
            title="Sign Up"
            onPress={() => router.push('/(auth)/Register')}
            outlined={false}
            buttonStyle={{
              paddingVertical: 15,
              width: '100%', // Full-width button
              borderRadius: 10,
              marginBottom: 15,
              alignItems: 'center',
              backgroundColor: '#ffffff', // White background
            }}
            textStyle={{
              color: '#000000',
              fontSize: 18,
              textAlign: 'center',
              fontWeight: 'bold',
            }}
          />

          {/* Additional Text Section */}
          <View style={styles.additionalTextContainer}>
            <Text style={styles.infoText}>
              By clicking Log in, you agree to the{' '}
              <Text style={styles.linkText}>Terms of Use</Text> and{' '}
              <Text style={styles.linkText}>Privacy Policy</Text>.
            </Text>
            <Text style={styles.infoText}>
            
            </Text>
          </View>
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    padding: 20,
    backgroundColor: '#121212', // Dark background
  },
  logoContainer: {
    alignItems: 'center',
    marginBottom: 30,
  },
  logo: {
    resizeMode: 'contain',
    alignSelf: 'center', // Center the logo horizontally
  },
  form: {
    marginTop: 20,
  },
  input: {
    borderWidth: 1,
    borderColor: '#ffffff', // White border for input fields
    padding: 12,
    marginBottom: 15,
    borderRadius: 10,
    backgroundColor: '#1e1e1e', // Dark background for input fields
    color: '#ffffff', // White text color
    fontSize: 16,
  },
  additionalTextContainer: {
    marginTop: 10,
    alignItems: 'center',
  },
  infoText: {
    fontSize: 12,
    color: '#ffffff', // White text color for info text
    textAlign: 'center',
    marginBottom: 5,
  },
  linkText: {
    color: '#ffffff', // White link color
    textDecorationLine: 'underline',
  },
});

export default LoginScreen;
