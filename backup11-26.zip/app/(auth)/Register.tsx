import React, { useState } from 'react';
import { View, Text, TextInput, StyleSheet, Alert, Image, Dimensions } from 'react-native';
import { useRouter } from 'expo-router';
import { auth } from '../../src/config/firebaseConfig';
import { createUserWithEmailAndPassword } from 'firebase/auth';
import { createUserAPI } from '../../src/utils/api';
import { TouchableOpacity } from 'react-native';


export default function Register() {
  const [email, setEmail] = useState<string>('');
  const [password, setPassword] = useState<string>('');
  const [confirmPassword, setConfirmPassword] = useState<string>('');
  const [error, setError] = useState<string>('');
  const router = useRouter();

  const { width } = Dimensions.get('window'); // Dynamically adjust screen width
  const logoSize = width * 0.5; // Set logo size as 50% of screen width

  const handleRegister = async () => {
    // Reset error state
    setError('');

    // Basic validation
    if (!email) {
      setError('Email is required!');
      return;
    }

    if (!password) {
      setError('Password is required!');
      return;
    }

    if (password !== confirmPassword) {
      setError('Passwords do not match!');
      return;
    }

    if (password.length < 6) {
      setError('Password must be at least 6 characters long');
      return;
    }

    try {
      // Create user with Firebase SDK
      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      const user = userCredential.user;
      console.log('User registered:', user);

      // Call the backend to create a Firestore document for the user
      await createUserAPI({
        id: user.uid,
        email,
        name: email.split('@')[0], // Optional: Extract name from email or add another input field for name
      });

      Alert.alert('Success', 'Account Created Successfully!', [
        { text: 'OK', onPress: () => router.push('/(auth)/Login') },
      ]);
    } catch (err: any) {
      console.error('Registration Error:', err);
      // Firebase SDK error handling
      switch (err.code) {
        case 'auth/email-already-in-use':
          setError('That email address is already in use!');
          break;
        case 'auth/invalid-email':
          setError('That email address is invalid!');
          break;
        case 'auth/weak-password':
          setError('Password should be at least 6 characters!');
          break;
        default:
          setError('An unexpected error occurred. Please try again.');
      }
    }
  };

  return (
    <View style={styles.container}>
      <View style={styles.logoContainer}>
        <Image
          source={require('../../src/assets/logo.png')}
          style={[styles.logo, { width: logoSize, height: logoSize }]}
          resizeMode="contain"
        />
      </View>
      <Text style={styles.title}>Register</Text>
      {error ? <Text style={styles.errorText}>{error}</Text> : null}
      <TextInput
        style={styles.input}
        placeholder="Email"
        placeholderTextColor="#ccc"
        value={email}
        onChangeText={setEmail}
        keyboardType="email-address"
        autoCapitalize="none"
        autoCorrect={false}
      />
      <TextInput
        style={styles.input}
        placeholder="Password"
        placeholderTextColor="#ccc"
        value={password}
        onChangeText={setPassword}
        secureTextEntry
        autoCapitalize="none"
        autoCorrect={false}
      />
      <TextInput
        style={styles.input}
        placeholder="Confirm Password"
        placeholderTextColor="#ccc"
        value={confirmPassword}
        onChangeText={setConfirmPassword}
        secureTextEntry
        autoCapitalize="none"
        autoCorrect={false}
      />
      <TouchableOpacity style={styles.button} onPress={handleRegister}>
        <Text style={styles.buttonText}>Register</Text>
      </TouchableOpacity>
      <TouchableOpacity onPress={() => router.push('/(auth)/Login')}>
        <Text style={styles.linkText}>Already have an account? Login</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    padding: 20,
    backgroundColor: '#000',
  },
  logoContainer: {
    alignItems: 'center',
    marginBottom: 30,
  },
  logo: {
    // Dynamically set with width and height from logoSize
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 20,
    textAlign: 'center',
  },
  input: {
    backgroundColor: '#1c1c1c',
    color: '#fff',
    borderRadius: 10,
    padding: 15,
    marginBottom: 15,
    borderWidth: 1,
    borderColor: '#fff',
  },
  button: {
    backgroundColor: '#fff',
    padding: 15,
    borderRadius: 10,
    alignItems: 'center',
    marginBottom: 15,
  },
  buttonText: {
    color: '#000',
    fontSize: 16,
    fontWeight: 'bold',
  },
  linkText: {
    color: '#fff',
    textAlign: 'center',
    marginTop: 20,
  },
  errorText: {
    color: '#ff4444',
    marginBottom: 10,
    textAlign: 'center',
  },
});
