import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  Image,
  TouchableOpacity,
  FlatList,
  StyleSheet,
  TextInput,
  ActivityIndicator,
  Alert,
  RefreshControl,
} from 'react-native';
import { useRouter } from 'expo-router';
import * as api from '../../src/utils/api';

type Event = {
  id: string;
  title: string;
  imageUrl: string;
  ticketLink?: string;
  date?: string; // Event date
};

const EventsScreen: React.FC = () => {
  const [events, setEvents] = useState<Event[]>([]);
  const [filteredEvents, setFilteredEvents] = useState<Event[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const router = useRouter();

  const fetchEventsData = async () => {
    setLoading(true);
    try {
      const fetchedEvents = await api.fetchEvents();
      const formattedEvents = fetchedEvents.map((event) => ({
        id: event.id,
        title: event.title,
        imageUrl: event.flyerUrl || 'https://via.placeholder.com/150', // Use flyerUrl for the image
        ticketLink: event.ticketLink,
        date: event.date, // Assuming date is in ISO format
      }));
  
      // Sort events by date (earliest first)
      const sortedEvents = formattedEvents.sort((a, b) => {
        if (a.date && b.date) {
          return new Date(a.date).getTime() - new Date(b.date).getTime();
        }
        return 0;
      });
  
      setEvents(sortedEvents);
      setFilteredEvents(sortedEvents);
    } catch (err) {
      console.error('Error fetching events:', err);
      setError('Failed to load events. Please try again later.');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };
  

  useEffect(() => {
    fetchEventsData();
  }, []);

  const handleSearch = (query: string) => {
    setSearchQuery(query);
    setFilteredEvents(
      query ? events.filter((e) => e.title.toLowerCase().includes(query.toLowerCase())) : events
    );
  };

  const handleTablePress = (event: Event) => {
    console.log('Event selected:', event);
    console.log('Event ID:', event.id);

    if (!event || !event.id) {
      Alert.alert('Error', 'Event details are missing. Please try again.');
      return;
    }

    console.log('Navigating to TableSelection with eventId:', event.id);

    router.push({
      pathname: '/reservations/TableSelection',
      params: { eventId: event.id, eventTitle: event.title, eventDate: event.date },
    });
  };

  const handleTicketPress = (ticketLink?: string) => {
    if (ticketLink) {
      Alert.alert('Open Tickets', `Opening ticket link: ${ticketLink}`);
    } else {
      Alert.alert('No Ticket Link', 'This event does not have a ticket link.');
    }
  };

  const renderEventCard = ({ item }: { item: Event }) => (
    <View style={styles.card}>
      <Image source={{ uri: item.imageUrl }} style={styles.image} />
      <View style={styles.infoContainer}>
        <Text style={styles.title}>{item.title}</Text>
        {item.date && (
          <Text style={styles.dateText}>Date: {new Date(item.date).toLocaleDateString()}</Text>
        )}
        <View style={styles.actions}>
          <TouchableOpacity
            style={[styles.button, styles.outlinedButton]}
            onPress={() => handleTablePress(item)}
          >
            <Text style={styles.buttonText}>Tables</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.button, styles.outlinedButton]}
            onPress={() => handleTicketPress(item.ticketLink)}
          >
            <Text style={styles.buttonText}>Tickets</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );

  const onRefresh = () => {
    setRefreshing(true);
    fetchEventsData();
  };

  return (
    <View style={styles.container}>
      <TextInput
        style={styles.searchInput}
        placeholder="Search events..."
        placeholderTextColor="#bbb"
        value={searchQuery}
        onChangeText={handleSearch}
      />
      {loading && !refreshing ? (
        <ActivityIndicator size="large" color="#fff" style={styles.loadingIndicator} />
      ) : error ? (
        <Text style={styles.errorText}>{error}</Text>
      ) : (
        <FlatList
          data={filteredEvents}
          renderItem={renderEventCard}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.list}
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor="#fff" />
          }
        />
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
  },
  searchInput: {
    height: 40,
    backgroundColor: '#1c1c1c',
    borderRadius: 10,
    paddingHorizontal: 10,
    color: '#fff',
    margin: 10,
  },
  list: {
    padding: 10,
  },
  card: {
    flexDirection: 'row',
    backgroundColor: '#1c1c1c',
    borderRadius: 10,
    marginVertical: 8,
    overflow: 'hidden',
  },
  image: {
    width: 80,
    height: 80,
    borderRadius: 10,
    margin: 10,
  },
  infoContainer: {
    flex: 1,
    padding: 10,
  },
  title: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  dateText: {
    color: '#bbb',
    fontSize: 14,
    marginBottom: 5,
  },
  actions: {
    flexDirection: 'row',
    marginTop: 5,
  },
  button: {
    paddingVertical: 5,
    paddingHorizontal: 15,
    borderRadius: 5,
    marginRight: 10,
  },
  outlinedButton: {
    borderWidth: 1,
    borderColor: '#fff',
    backgroundColor: 'transparent',
  },
  buttonText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: 'bold',
  },
  loadingIndicator: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    height: '100%',
  },
  errorText: {
    color: 'red',
    textAlign: 'center',
    fontSize: 16,
    marginTop: 20,
  },
});

export default EventsScreen;
