import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  ActivityIndicator,
  Alert,
  Image,
  TextInput,
  TouchableOpacity,
} from 'react-native';
import { useRouter } from 'expo-router';
import { Stack } from 'expo-router';
import * as ImagePicker from 'expo-image-picker';
import { db } from '../../src/config/firebaseConfig';
import {
  collection,
  doc,
  addDoc,
  updateDoc,
  deleteDoc,
  getDocs,
  query,
  orderBy,
  increment,
} from 'firebase/firestore';
import { MaterialIcons } from '@expo/vector-icons';

const CommunityScreen: React.FC = () => {
  const [communityData, setCommunityData] = useState<
    Array<{ id: string; text: string; image?: string; likes: number; comments: Array<{ user: string; comment: string }> }>
  >([]);
  const [loading, setLoading] = useState(false);
  const [newComment, setNewComment] = useState('');
  const [newImage, setNewImage] = useState<string | null>(null);
  const [commentText, setCommentText] = useState('');
  const [selectedPost, setSelectedPost] = useState<string | null>(null); // ID of post for commenting

  const router = useRouter();

  useEffect(() => {
    fetchCommunityData();
  }, []);

  const fetchCommunityData = async () => {
    setLoading(true);
    try {
      const communityRef = collection(db, 'communityPosts');
      const communityQuery = query(communityRef, orderBy('createdAt', 'desc'));
      const querySnapshot = await getDocs(communityQuery);

      const fetchedData = querySnapshot.docs.map((doc) => ({
        id: doc.id,
        ...(doc.data() as any),
      }));
      setCommunityData(fetchedData);
    } catch (error) {
      console.error('Error fetching community data:', error);
      Alert.alert('Error', 'Failed to load community data.');
    } finally {
      setLoading(false);
    }
  };

  const addNewPost = async () => {
    if (newComment.trim() === '') {
      Alert.alert('Empty Post', 'Please add text to your post before submitting.');
      return;
    }

    try {
      const communityRef = collection(db, 'communityPosts');
      const newPost = {
        text: newComment,
        image: newImage || null,
        likes: 0,
        comments: [],
        createdAt: new Date(),
      };
      await addDoc(communityRef, newPost);
      fetchCommunityData(); // Refresh posts
      setNewComment('');
      setNewImage(null);
    } catch (error) {
      console.error('Error posting message:', error);
      Alert.alert('Error', 'Failed to post your message.');
    }
  };

  const likePost = async (postId: string) => {
    try {
      const postRef = doc(db, 'communityPosts', postId);
      await updateDoc(postRef, {
        likes: increment(1),
      });
      fetchCommunityData();
    } catch (error) {
      console.error('Error liking post:', error);
    }
  };

  const addComment = async () => {
    if (!selectedPost || commentText.trim() === '') {
      Alert.alert('Empty Comment', 'Please write a comment before submitting.');
      return;
    }

    try {
      const postRef = doc(db, 'communityPosts', selectedPost);
      const currentPost = communityData.find((post) => post.id === selectedPost);

      await updateDoc(postRef, {
        comments: [
          ...(currentPost?.comments || []),
          { user: 'Anonymous', comment: commentText },
        ],
      });

      setCommentText('');
      setSelectedPost(null);
      fetchCommunityData();
    } catch (error) {
      console.error('Error adding comment:', error);
    }
  };

  const pickImage = async () => {
    const permissionResult = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!permissionResult.granted) {
      Alert.alert('Permission Denied', 'Permission to access the camera roll is required!');
      return;
    }

    const pickerResult = await ImagePicker.launchImageLibraryAsync();
    if (!pickerResult.canceled && pickerResult.assets.length > 0) {
      setNewImage(pickerResult.assets[0].uri);
    }
  };

  const handleMenuPress = (postId: string) => {
    Alert.alert('Post Options', 'Choose an action:', [
      { text: 'Edit', onPress: () => console.log(`Editing post ${postId}`) },
      {
        text: 'Delete',
        onPress: () => deletePost(postId),
        style: 'destructive',
      },
      { text: 'Cancel', style: 'cancel' },
    ]);
  };

  const deletePost = async (postId: string) => {
    try {
      const postRef = doc(db, 'communityPosts', postId);
      await deleteDoc(postRef);
      fetchCommunityData(); // Refresh posts
    } catch (error) {
      console.error('Error deleting post:', error);
    }
  };

  return (
    <View style={styles.container}>
      <Stack.Screen options={{ title: 'Community' }} />
      {loading ? (
        <ActivityIndicator size="large" color="#fff" style={styles.loadingIndicator} />
      ) : (
        <>
          <View style={styles.postContainer}>
            {newImage && <Image source={{ uri: newImage }} style={styles.newImagePreview} />}
            <TextInput
              style={styles.input}
              placeholder="Write a post..."
              placeholderTextColor="#aaa"
              value={newComment}
              onChangeText={setNewComment}
            />
            <View style={styles.postButtons}>
              <TouchableOpacity style={styles.imageButton} onPress={pickImage}>
                <Text style={styles.buttonText}>Add Image</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.postButton} onPress={addNewPost}>
                <Text style={styles.buttonText}>Post</Text>
              </TouchableOpacity>
            </View>
          </View>
          <FlatList
            data={communityData}
            renderItem={({ item }) => (
              <View style={styles.card}>
                <View style={styles.cardHeader}>
                  <Text style={styles.cardText}>{item.text}</Text>
                  <TouchableOpacity onPress={() => handleMenuPress(item.id)}>
                    <MaterialIcons name="more-vert" size={24} color="#fff" />
                  </TouchableOpacity>
                </View>
                {item.image && <Image source={{ uri: item.image }} style={styles.cardImage} />}
                <Text style={styles.likesText}>{item.likes} Likes</Text>
                <TouchableOpacity style={styles.button} onPress={() => likePost(item.id)}>
                  <Text style={styles.buttonText}>Like</Text>
                </TouchableOpacity>
                <Text style={styles.commentTitle}>Comments:</Text>
                {item.comments.map((comment, index) => (
                  <Text key={index} style={styles.commentText}>
                    {comment.user}: {comment.comment}
                  </Text>
                ))}
                <TextInput
                  style={styles.commentInput}
                  placeholder="Add a comment..."
                  placeholderTextColor="#aaa"
                  value={selectedPost === item.id ? commentText : ''}
                  onChangeText={setCommentText}
                  onFocus={() => setSelectedPost(item.id)}
                />
                <TouchableOpacity style={styles.commentButton} onPress={addComment}>
                  <Text style={styles.buttonText}>Post Comment</Text>
                </TouchableOpacity>
              </View>
            )}
            keyExtractor={(item) => item.id}
          />
        </>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#000', padding: 20 },
  loadingIndicator: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  postContainer: { backgroundColor: '#1c1c1c', padding: 15, borderRadius: 10, marginBottom: 20 },
  input: { backgroundColor: '#2c2c2c', color: '#fff', borderRadius: 5, padding: 10, marginBottom: 10 },
  postButtons: { flexDirection: 'row', justifyContent: 'space-between' },
  imageButton: { backgroundColor: '#444', paddingVertical: 10, paddingHorizontal: 20, borderRadius: 5 },
  postButton: { backgroundColor: '#444', paddingVertical: 10, paddingHorizontal: 20, borderRadius: 5 },
  card: { backgroundColor: '#1c1c1c', padding: 15, borderRadius: 10, marginBottom: 15 },
  cardHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  cardImage: { width: '100%', height: 150, borderRadius: 10, marginBottom: 10 },
  cardText: { color: '#fff', fontSize: 16, marginBottom: 10 },
  likesText: { color: '#fff', marginBottom: 10 },
  commentTitle: { color: '#fff', fontWeight: 'bold', marginTop: 10 },
  commentText: { color: '#aaa', marginBottom: 5 },
  commentInput: { backgroundColor: '#2c2c2c', color: '#fff', borderRadius: 5, padding: 10, marginBottom: 10 },
  commentButton: { backgroundColor: '#444', padding: 10, borderRadius: 5 },
  buttonText: { color: '#fff', fontWeight: 'bold', textAlign: 'center' },
});

export default CommunityScreen;
