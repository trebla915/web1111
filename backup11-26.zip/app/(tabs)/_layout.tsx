import React from 'react';
import { View, StyleSheet, TouchableOpacity, Text } from 'react-native';
import { Tabs } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { UserProvider } from '../../src/contexts/UserContext'; // Wrap in UserContext

const TabLayout: React.FC = () => {
  return (
    <UserProvider>
      <View style={{ flex: 1, backgroundColor: '#000' }}>
        <Tabs
          screenOptions={{
            tabBarStyle: {
              backgroundColor: '#000',
              borderTopColor: 'gray',
            },
            tabBarActiveTintColor: '#fff', // Set the active tint color to white
            tabBarInactiveTintColor: 'gray',
            headerStyle: {
              backgroundColor: '#000',
              borderBottomWidth: 1,
              borderBottomColor: 'gray',
            },
            headerTintColor: '#fff',
            headerLeft: () => (
              <TouchableOpacity style={styles.headerIconContainer}>
                <Ionicons name="menu" size={24} color="#fff" />
              </TouchableOpacity>
            ),
            headerRight: () => (
              <TouchableOpacity style={styles.headerIconContainer}>
                <Ionicons name="notifications" size={24} color="#fff" />
              </TouchableOpacity>
            ),
          }}
        >
          {/* Reordered the tabs as requested */}
          <Tabs.Screen
            name="index"
            options={{
              title: 'Home',
              tabBarIcon: ({ color, size }) => (
                <Ionicons name="home" size={size} color={color} />
              ),
            }}
          />
          <Tabs.Screen
            name="events"
            options={{
              title: 'Events',
              tabBarIcon: ({ color, size }) => (
                <Ionicons name="calendar" size={size} color={color} />
              ),
            }}
          />
          <Tabs.Screen
            name="community"
            options={{
              title: 'Community',
              tabBarIcon: ({ color, size }) => (
                <Ionicons name="people" size={size} color={color} />
              ),
            }}
          />
          <Tabs.Screen
            name="account"
            options={{
              title: 'Account',
              tabBarIcon: ({ color, size }) => (
                <Ionicons name="person" size={size} color={color} />
              ),
            }}
          />
        </Tabs>
      </View>
    </UserProvider>
  );
};

const styles = StyleSheet.create({
  headerIconContainer: {
    marginHorizontal: 10,
    justifyContent: 'center',
    alignItems: 'center',
  },
});

export default TabLayout;
