import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Image,
  ActivityIndicator,
  Dimensions,
} from "react-native";
import { useAuth } from "../../src/contexts/AuthContext"; // Assumes a context for user auth
import { fetchAllEvents } from "../../src/utils/events"; // Ensure you import the correct function

const screenWidth = Dimensions.get("window").width;

export const HomeScreen = () => {
  const { firebaseUser } = useAuth();
  const [upcomingEvent, setUpcomingEvent] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const getUpcomingEvent = async () => {
      setLoading(true);
      try {
        const events = await fetchAllEvents(); // Fetch all events
        // Assuming events are sorted by date, pick the first upcoming one
        const nextEvent = events.length > 0 ? events[0] : null;
        setUpcomingEvent(nextEvent);
      } catch (error) {
        console.error("Error fetching events:", error);
      } finally {
        setLoading(false);
      }
    };
    getUpcomingEvent();
  }, []);

  return (
    <ScrollView style={styles.container}>
      {/* Club Logo */}
      <View style={styles.logoContainer}>
        <Image
          source={require("../../src/assets/logo.png")} // Update to the correct logo path
          style={styles.clubLogo}
        />
      </View>

      {/* Welcome Section */}
      <View style={styles.section}>
        <Text style={styles.welcomeText}>
          Welcome, {firebaseUser?.displayName || "Guest"}!
        </Text>
        <Text style={styles.subText}>
          Every moment is a chance to align with your purpose.
        </Text>
      </View>

      {/* Upcoming Event Section */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Upcoming Event</Text>
        {loading ? (
          <ActivityIndicator size="large" color="#fff" />
        ) : upcomingEvent ? (
          <View style={styles.eventCard}>
            <Image
              source={{
                uri:
                  upcomingEvent.flyerUrl || "https://via.placeholder.com/300",
              }}
              style={styles.eventImage}
            />
            <Text style={styles.eventTitle}>{upcomingEvent.title}</Text>
            <Text style={styles.eventDate}>
              {new Date(upcomingEvent.date || Date.now()).toLocaleDateString()}
            </Text>
          </View>
        ) : (
          <Text style={styles.noEventText}>
            No upcoming events at the moment.
          </Text>
        )}
      </View>

      {/* Club Highlights Section */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Club Highlights</Text>
        <ScrollView horizontal>
          <Image
            source={{ uri: "https://via.placeholder.com/300x150" }}
            style={styles.highlightImage}
          />
          <Image
            source={{ uri: "https://via.placeholder.com/300x150" }}
            style={styles.highlightImage}
          />
        </ScrollView>
      </View>

      {/* VIP Booking Shortcut */}
      <TouchableOpacity style={styles.vipButton}>
        <Text style={styles.vipButtonText}>Book Your VIP Table Now</Text>
      </TouchableOpacity>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#000",
    paddingHorizontal: 20,
  },
  logoContainer: {
    alignItems: "center",
    marginBottom: 10,
    marginTop: 10, // Adjusted margin for better placement
  },
  clubLogo: {
    width: screenWidth * 0.8, // 80% of screen width
    height: screenWidth * 0.3, // Maintain aspect ratio for the logo
    resizeMode: "contain",
  },
  section: {
    marginBottom: 20,
  },
  welcomeText: {
    fontSize: 26, // Slightly larger for emphasis
    fontWeight: "bold",
    color: "#fff",
    textAlign: "center",
    marginBottom: 5, // Reduced gap between Welcome and quote
    marginTop: -5, // Scoot Welcome closer to the top
  },
  subText: {
    fontSize: 16,
    color: "#aaa",
    textAlign: "center",
    fontStyle: "italic",
  },
  sectionTitle: {
    fontSize: 20,
    color: "#fff",
    marginBottom: 10,
  },
  eventCard: {
    backgroundColor: "#1c1c1c",
    borderRadius: 10,
    padding: 10,
    alignItems: "center",
  },
  eventImage: {
    width: screenWidth - 40,
    height: screenWidth - 40, // Make it square
    borderRadius: 10,
    marginBottom: 10,
    resizeMode: "cover",
  },
  eventTitle: {
    fontSize: 18,
    color: "#fff",
    marginBottom: 5,
  },
  eventDate: {
    fontSize: 16,
    color: "#aaa",
  },
  noEventText: {
    fontSize: 16,
    color: "#aaa",
    textAlign: "center",
  },
  highlightImage: {
    width: 300,
    height: 150,
    borderRadius: 10,
    marginRight: 10,
  },
  vipButton: {
    backgroundColor: "#fff",
    padding: 15,
    borderRadius: 10,
    alignItems: "center",
    marginBottom: 20,
  },
  vipButtonText: {
    color: "#000",
    fontSize: 18,
    fontWeight: "bold",
  },
});

export default HomeScreen;
