import React from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  Image,
  Alert,
  ActivityIndicator,
} from 'react-native';
import { useAuth } from '../../src/contexts/AuthContext';
import { useRouter } from 'expo-router';

const AccountScreen: React.FC = () => {
  const { firebaseUser, signOut, isLoading } = useAuth();
  const router = useRouter();

  const handleLogout = async () => {
    try {
      await signOut();
      Alert.alert('Logged Out', 'You have been successfully logged out.');
      router.replace('/(auth)/Login');
    } catch (error) {
      console.error('Error logging out:', error);
      Alert.alert('Logout Failed', 'Something went wrong while logging out.');
    }
  };

  const handleNavigateToAdmin = () => {
    router.push('/(admin)/Dashboard');
  };

  if (isLoading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#fff" />
        <Text style={styles.loadingText}>Loading user information...</Text>
      </View>
    );
  }

  if (!firebaseUser) {
    return (
      <View style={styles.container}>
        <Text style={styles.infoText}>No user is currently logged in.</Text>
        <TouchableOpacity
          style={[styles.button, styles.outlinedButton]}
          onPress={() => router.replace('/(auth)/Login')}
        >
          <Text style={styles.buttonText}>Go to Login</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {/* User Avatar */}
      <View style={styles.avatarContainer}>
        <Image
          source={{ uri: firebaseUser.photoURL || 'https://via.placeholder.com/150' }}
          style={styles.avatar}
        />
      </View>

      {/* User Information */}
      <View style={styles.userInfoContainer}>
        <Text style={styles.userName}>{firebaseUser.displayName || 'John Doe'}</Text>
        <Text style={styles.userEmail}>{firebaseUser.email || 'johndoe@example.com'}</Text>
      </View>

      {/* Edit Profile Button */}
      <TouchableOpacity
        style={[styles.button, styles.outlinedButton]}
        onPress={() => console.log('Edit profile button pressed')}
      >
        <Text style={styles.buttonText}>Edit Profile</Text>
      </TouchableOpacity>

      {/* Navigate to Admin Dashboard Button */}
      <TouchableOpacity
        style={[styles.button, styles.outlinedButton]}
        onPress={handleNavigateToAdmin}
      >
        <Text style={styles.buttonText}>Go to Admin Dashboard</Text>
      </TouchableOpacity>

      {/* Logout Button */}
      <TouchableOpacity
        style={[styles.button, styles.outlinedButton]}
        onPress={handleLogout}
      >
        <Text style={styles.buttonText}>Logout</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
    alignItems: 'center',
    padding: 20,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#000',
  },
  loadingText: {
    color: '#fff',
    marginTop: 10,
    fontSize: 16,
  },
  avatarContainer: {
    marginBottom: 20,
  },
  avatar: {
    width: 120,
    height: 120,
    borderRadius: 60,
    borderWidth: 2,
    borderColor: '#fff',
  },
  userInfoContainer: {
    alignItems: 'center',
    marginBottom: 20,
  },
  userName: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#fff',
  },
  userEmail: {
    fontSize: 16,
    color: '#aaa',
  },
  infoText: {
    color: '#fff',
    fontSize: 16,
    textAlign: 'center',
    marginBottom: 20,
  },
  button: {
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 5,
    marginVertical: 10,
    width: '80%',
    alignItems: 'center',
  },
  outlinedButton: {
    borderWidth: 1,
    borderColor: '#fff',
    backgroundColor: 'transparent',
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default AccountScreen;
