import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import CustomButton from '../../src/components/CustomButton';
import { useRouter } from 'expo-router';

const ManageUsers = () => {
  const router = useRouter();

  const handleAddUser = () => {
    console.log('Add User Pressed');
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Manage Users</Text>
      <CustomButton title="Add User" onPress={handleAddUser} />
      <CustomButton title="Back to Dashboard" onPress={() => router.push('/(admin)/Dashboard')} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
    alignItems: 'center',
    padding: 20,
  },
  title: {
    color: '#fff',
    fontSize: 24,
    fontWeight: 'bold',
  },
});

export default ManageUsers;
