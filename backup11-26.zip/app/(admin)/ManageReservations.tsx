import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, ActivityIndicator } from 'react-native';
import { useRouter } from 'expo-router';
import * as api from '../../src/utils/api';
import CustomButton from '../../src/components/CustomButton';

type Reservation = {
  id: string;
  eventId: string;
  tableId: string;
  tableNumber: number;
  userId: string;
  reservationTime: string;
  guestCount: number;
};

type ReservationsByEvent = {
  [eventTitle: string]: Reservation[];
};

const ManageReservations = () => {
  const [reservationsByEvent, setReservationsByEvent] = useState<ReservationsByEvent>({});
  const [expandedEventId, setExpandedEventId] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const router = useRouter();

  useEffect(() => {
    const fetchReservations = async () => {
      setLoading(true);
      try {
        const response = await api.fetchAllReservationsGroupedByEvent();

        // Check if the response is structured with success and data keys
        if (response?.success && response?.data) {
          const reservationsData = response.data;

          // Ensure the response is a valid object and contains reservation arrays
          if (!reservationsData || typeof reservationsData !== 'object' || Array.isArray(reservationsData)) {
            throw new Error('Invalid response format');
          }

          // Ensure each key maps to an array of reservations
          const formattedResponse: ReservationsByEvent = {};
          for (const [eventId, reservations] of Object.entries(reservationsData)) {
            if (Array.isArray(reservations)) {
              formattedResponse[eventId] = reservations;
            } else {
              console.error('Invalid reservations format for eventId:', eventId);
            }
          }

          // Replace event IDs with event titles if available
          const events = await api.fetchEvents();
          const eventTitleMap: { [key: string]: string } = {};
          events.forEach((event) => {
            eventTitleMap[event.id] = event.title;
          });

          const reservationsByEventTitle: ReservationsByEvent = {};
          for (const [eventId, reservations] of Object.entries(formattedResponse)) {
            const eventTitle = eventTitleMap[eventId] || eventId;
            reservationsByEventTitle[eventTitle] = reservations;
          }

          setReservationsByEvent(reservationsByEventTitle);
          setError(null);
        } else {
          throw new Error('Unexpected response format');
        }
      } catch (error) {
        console.error('Error fetching reservations:', error);
        setError('Failed to load reservations. Please try again.');
      } finally {
        setLoading(false);
      }
    };

    fetchReservations();
  }, []);

  const toggleEventExpand = (eventTitle: string) => {
    setExpandedEventId(expandedEventId === eventTitle ? null : eventTitle);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Manage Reservations</Text>
      {loading ? (
        <ActivityIndicator size="large" color="#fff" style={styles.loadingIndicator} />
      ) : error ? (
        <Text style={styles.errorText}>{error}</Text>
      ) : (
        <ScrollView>
          {Object.entries(reservationsByEvent).map(([eventTitle, reservations]) => {
            if (!Array.isArray(reservations)) {
              console.error('Invalid reservations data format:', reservations);
              return null;
            }

            return (
              <View key={eventTitle} style={styles.eventContainer}>
                <CustomButton
                  title={eventTitle}
                  onPress={() => toggleEventExpand(eventTitle)}
                  outlined={true}
                />
                {expandedEventId === eventTitle && (
                  <View style={styles.reservationsList}>
                    {reservations.length === 0 ? (
                      <Text style={styles.noReservationsText}>
                        No reservations found for this event.
                      </Text>
                    ) : (
                      reservations.map((reservation) => (
                        <View key={reservation.id} style={styles.reservationItem}>
                          <Text style={styles.reservationText}>
                            Table Number: {reservation.tableNumber}, Reserved by User: {reservation.userId}, Guests: {reservation.guestCount}
                          </Text>
                        </View>
                      ))
                    )}
                  </View>
                )}
              </View>
            );
          })}
        </ScrollView>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#000',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    color: '#fff',
  },
  eventContainer: {
    marginBottom: 15,
    backgroundColor: '#1c1c1c',
    borderRadius: 10,
  },
  reservationsList: {
    padding: 10,
    backgroundColor: '#1c1c1c',
    borderBottomLeftRadius: 10,
    borderBottomRightRadius: 10,
  },
  reservationItem: {
    paddingVertical: 5,
    borderBottomColor: '#333',
    borderBottomWidth: 1,
  },
  reservationText: {
    color: '#fff',
    fontSize: 14,
  },
  noReservationsText: {
    color: '#bbb',
    fontSize: 14,
    textAlign: 'center',
    marginVertical: 10,
  },
  loadingIndicator: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    height: '100%',
  },
  errorText: {
    color: 'red',
    textAlign: 'center',
    fontSize: 16,
    marginTop: 20,
  },
});

export default ManageReservations;
