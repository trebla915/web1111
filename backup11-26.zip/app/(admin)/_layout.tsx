import React from 'react';
import { Stack } from 'expo-router';
import { AuthProvider, useAuth } from '../../src/contexts/AuthContext';
import { View, ActivityIndicator, TouchableOpacity, Text, StyleSheet } from 'react-native';
import { useRouter } from 'expo-router';

export default function AdminLayout() {
  const { firebaseUser, isLoading } = useAuth(); // Access user authentication state
  const router = useRouter();

  // Show a loading indicator while checking the authentication status
  if (isLoading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#6200ea" />
      </View>
    );
  }

  return (
    <Stack
      screenOptions={{
        headerStyle: {
          backgroundColor: '#000000', // Make header black
        },
        headerTintColor: '#ffffff', // Set the text color to white for contrast
        headerTitleStyle: {
          fontWeight: 'bold',
        },
        headerRight: () => (
          <TouchableOpacity
            onPress={() => router.replace('/')}
            style={styles.homeButton}
          >
            <Text style={styles.homeButtonText}>Home</Text>
          </TouchableOpacity>
        ),
      }}
    >
      {/* Corrected stack screen names to match the filenames */}
      <Stack.Screen name="Dashboard" options={{ title: 'Admin Dashboard' }} />
      <Stack.Screen name="CreateEvent" options={{ title: 'Create Event' }} />
      <Stack.Screen name="CreateReservations" options={{ title: 'Create Reservations' }} />
      <Stack.Screen name="ManageReservations" options={{ title: 'Manage Reservations' }} />
      <Stack.Screen name="ManageUsers" options={{ title: 'Manage Users' }} />
    </Stack>
  );
}

const styles = StyleSheet.create({
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  homeButton: {
    marginRight: 16,
    padding: 8,
    backgroundColor: '#ffffff',
    borderRadius: 4,
  },
  homeButtonText: {
    color: '#6200ea',
    fontWeight: '600',
  },
});
