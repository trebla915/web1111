import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  Alert,
  StyleSheet,
  Modal,
  ActivityIndicator,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
  Image,
  Dimensions,
} from 'react-native';
import { useAuth } from '../../src/contexts/AuthContext';
import * as ImagePicker from 'expo-image-picker';
import DateTimePicker from '@react-native-community/datetimepicker';
import { uploadImageToStorage } from '../../src/utils/uploadImageToStorage';
import CustomButton from '../../src/components/CustomButton';
import { createNewEvent } from '../../src/utils/events';

const screenWidth = Dimensions.get('window').width;

const CreateEvent: React.FC = () => {
  const { firebaseUser, token } = useAuth();
  const [eventName, setEventName] = useState('');
  const [flyerUri, setFlyerUri] = useState<string | null>(null);
  const [ticketLink, setTicketLink] = useState('');
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [loading, setLoading] = useState(false);

  const validateForm = () => {
    if (!eventName.trim()) {
      Alert.alert('Validation Error', 'Event name is required.');
      return false;
    }
    if (!selectedDate) {
      Alert.alert('Validation Error', 'Event date is required.');
      return false;
    }
    return true;
  };

  const pickFlyerImage = async () => {
    try {
      const result = await ImagePicker.launchImageLibraryAsync({
        allowsEditing: true,
        aspect: [4, 3],
        quality: 0.5,
      });
      if (!result.canceled) {
        setFlyerUri(result.assets?.[0]?.uri || null);
      }
    } catch (error) {
      console.error('Error selecting image:', error);
      Alert.alert('Error', 'Failed to select image.');
    }
  };

  const handleCreateEvent = async () => {
    if (!firebaseUser || !token) {
      Alert.alert('Error', 'You must be logged in to create an event.');
      return;
    }

    if (!validateForm()) return;

    setLoading(true);
    try {
      let flyerUrl = '';

      if (flyerUri) {
        const filePath = `flyers/${firebaseUser.uid}/${Date.now()}_${eventName.trim()}.jpg`;
        flyerUrl = await uploadImageToStorage(flyerUri, filePath);
      }

      const eventData = {
        title: eventName.trim(),
        date: selectedDate?.toISOString(),
        ticketLink: ticketLink.trim(),
        flyerUrl,
        userId: firebaseUser.uid,
      };

      await createNewEvent(eventData);
      Alert.alert('Success', 'Event created successfully!');

      // Clear form fields after success
      setEventName('');
      setFlyerUri(null);
      setTicketLink('');
      setSelectedDate(null);
    } catch (error) {
      console.error('[handleCreateEvent] Error creating event:', error);
      Alert.alert('Error', 'Failed to create event.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContainer}>
        <Text style={styles.header}>Create New Event</Text>

        <Text style={styles.label}>Event Name *</Text>
        <TextInput
          style={styles.input}
          placeholder="Enter event name"
          placeholderTextColor="#bbb"
          value={eventName}
          onChangeText={setEventName}
        />

        <Text style={styles.label}>Event Date *</Text>
        <View style={styles.datePickerContainer}>
          <DateTimePicker
            value={selectedDate || new Date()}
            mode="date"
            display="default"
            textColor="#fff" // Ensures the text is white
            onChange={(event, date) => {
              if (date) setSelectedDate(date);
            }}
          />
        </View>

        <Text style={styles.label}>Ticket Link (Optional)</Text>
        <TextInput
          style={styles.input}
          placeholder="Enter ticket link"
          placeholderTextColor="#bbb"
          value={ticketLink}
          onChangeText={setTicketLink}
        />

        <Text style={styles.label}>Upload Flyer (Optional)</Text>
        <CustomButton title={flyerUri ? 'Change Flyer' : 'Upload Flyer'} onPress={pickFlyerImage} />
        {flyerUri && (
          <View style={styles.flyerContainer}>
            <Image source={{ uri: flyerUri }} style={styles.imagePreview} />
            <CustomButton title="Remove Flyer" onPress={() => setFlyerUri(null)} outlined />
          </View>
        )}

        <CustomButton title="Create Event" onPress={handleCreateEvent} disabled={loading} />

        {loading && (
          <Modal transparent>
            <View style={styles.loadingModal}>
              <ActivityIndicator size="large" color="#fff" />
            </View>
          </Modal>
        )}
      </ScrollView>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
  },
  scrollContainer: {
    padding: 16,
    justifyContent: 'center',
    alignItems: 'center', // Center content horizontally
  },
  header: {
    fontSize: 28,
    fontWeight: 'bold',
    marginBottom: 24,
    color: '#fff',
    textAlign: 'center',
  },
  label: {
    fontSize: 18,
    fontWeight: '500',
    marginBottom: 8,
    color: '#fff',
    alignSelf: 'flex-start',
  },
  input: {
    width: '100%',
    height: 50,
    backgroundColor: '#1c1c1c',
    borderRadius: 8,
    paddingHorizontal: 16,
    marginBottom: 16,
    fontSize: 16,
    color: '#fff',
  },
  datePickerContainer: {
    width: '100%',
    backgroundColor: '#1c1c1c',
    borderRadius: 8,
    padding: 12,
    marginBottom: 16,
  },
  flyerContainer: {
    alignItems: 'center',
    marginBottom: 16,
  },
  imagePreview: {
    width: screenWidth - 32,
    height: (screenWidth - 32) * 0.75,
    borderRadius: 8,
    marginBottom: 8,
  },
  loadingModal: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
  },
});

export default CreateEvent;
