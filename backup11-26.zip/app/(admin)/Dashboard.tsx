import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native'; 
import { useRouter } from 'expo-router';
import { TabView } from 'react-native-tab-view'; 

// Import the components for each screen
import CreateEvent from '../(admin)/CreateEvent';
import ManageUsers from './ManageUsers';
import ManageReservations from './ManageReservations';

const Dashboard = () => {
  const [index, setIndex] = React.useState(0);
  const [routes] = React.useState([
    { key: 'createEvent', title: 'Create Event' },
    { key: 'manageUsers', title: 'Manage Users' },
    { key: 'manageReservations', title: 'Manage Reservations' },
    { key: 'createReservation', title: 'Create Reservation' },
  ]);

  const router = useRouter();

  const renderScene = ({ route }: { route: any }) => {
    switch (route.key) {
      case 'createEvent':
        return <CreateEvent />; // Render CreateEvent component for this tab
      case 'manageUsers':
        return <ManageUsers />; // Render ManageUsers component
      case 'manageReservations':
        return <ManageReservations />; // Render ManageReservations component
      case 'createReservation':
        return (
          <View style={styles.tabContent}>
            <Text>Create Reservation Screen</Text>
          </View>
        );
      default:
        return null;
    }
  };

  return (
    <View style={styles.container}>
      <TabView
        navigationState={{ index, routes }}
        renderScene={renderScene}
        onIndexChange={setIndex}
        initialLayout={{ width: 300 }}
        style={styles.tabView}  
        renderTabBar={({ navigationState, jumpTo }) => (
          <View style={styles.tabBar}>
            {navigationState.routes.map((route, i) => (
              <TouchableOpacity
                key={route.key}
                style={[styles.tabButton, i === index && styles.activeTab]}
                onPress={() => jumpTo(route.key)}>
                <Text style={[styles.tabButtonText, i === index && styles.activeTabText]}>
                  {route.title}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        )}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000', // Set the background color to black
  },
  tabContent: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  tabBar: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    backgroundColor: '#1c1c1c', // Dark background for tab bar
    padding: 10,
  },
  tabButton: {
    padding: 10,
    borderRadius: 5,
  },
  activeTab: {
    backgroundColor: '#000000', // Set a red or any accent color to match app styling
  },
  tabButtonText: {
    color: '#fff', // Set button text color to white
    fontSize: 16,
  },
  activeTabText: {
    color: '#fff', // Set text color for active tab to white
    fontWeight: 'bold',
  },
  tabView: { 
    flex: 1,
  },
});

export default Dashboard;
