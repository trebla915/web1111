// app/(admin)/CreateReservation.tsx
import React, { useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet, Alert } from 'react-native';
import { useRouter } from 'expo-router';
import { FAB } from 'react-native-paper'; // FAB for other actions if needed

const CreateReservation = () => {
  const router = useRouter();
  const [guestName, setGuestName] = useState('');
  const [eventType, setEventType] = useState('');
  const [reservationDate, setReservationDate] = useState('');
  const [status, setStatus] = useState('Pending');

  // Handle form submission to create a new reservation
  const handleSubmit = () => {
    if (!guestName || !eventType || !reservationDate) {
      Alert.alert('Missing Information', 'Please fill in all fields');
      return;
    }

    const newReservation = {
      guestName,
      eventType,
      reservationDate,
      status,
    };

    // In a real app, you would send `newReservation` to the API to save it
    console.log('New Reservation:', newReservation);

    // Navigate back to the reservations page or another appropriate page
    router.push('/(admin)/ManageReservations'); // Adjust this to the correct route
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Create New Reservation</Text>

      {/* Guest Name */}
      <TextInput
        style={styles.input}
        placeholder="Guest Name"
        value={guestName}
        onChangeText={setGuestName}
      />

      {/* Event Type */}
      <TextInput
        style={styles.input}
        placeholder="Event Type"
        value={eventType}
        onChangeText={setEventType}
      />

      {/* Reservation Date */}
      <TextInput
        style={styles.input}
        placeholder="Reservation Date"
        value={reservationDate}
        onChangeText={setReservationDate}
      />

      {/* Status (e.g., Pending, Confirmed, etc.) */}
      <TextInput
        style={styles.input}
        placeholder="Status"
        value={status}
        onChangeText={setStatus}
      />

      {/* Submit Button */}
      <Button title="Create Reservation" onPress={handleSubmit} color="#6200ea" />

      {/* Optionally add a FAB button for additional actions */}
      <FAB
        style={styles.fab}
        small
        icon="check"
        label="Create"
        onPress={handleSubmit}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#fff',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 20,
  },
  input: {
    height: 50,
    borderColor: '#ddd',
    borderWidth: 1,
    marginBottom: 15,
    paddingLeft: 10,
    borderRadius: 5,
  },
  fab: {
    position: 'absolute',
    bottom: 30,
    right: 30,
    backgroundColor: '#6200ea',
  },
});

export default CreateReservation;