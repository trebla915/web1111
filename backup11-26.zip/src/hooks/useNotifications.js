import { useEffect } from "react";
import * as Notifications from "expo-notifications";

export const useNotifications = () => {
  useEffect(() => {
    const subscription = Notifications.addNotificationReceivedListener((notification) => {
      console.log("Notification Received:", notification);
    });

    const responseSubscription = Notifications.addNotificationResponseReceivedListener((response) => {
      console.log("Notification Clicked:", response);
    });

    return () => {
      subscription.remove();
      responseSubscription.remove();
    };
  }, []);
};
