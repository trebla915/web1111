import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import { getStorage } from 'firebase/storage';
import { getMessaging, getToken, Messaging } from 'firebase/messaging';
import Constants from 'expo-constants';

// Retrieve Firebase configuration from Expo constants
const firebaseConfig = {
  apiKey: Constants.expoConfig?.extra?.firebase?.apiKey || '',
  authDomain: Constants.expoConfig?.extra?.firebase?.authDomain || '',
  projectId: Constants.expoConfig?.extra?.firebase?.projectId || '',
  storageBucket: Constants.expoConfig?.extra?.firebase?.storageBucket || '',
  messagingSenderId: Constants.expoConfig?.extra?.firebase?.messagingSenderId || '',
  appId: Constants.expoConfig?.extra?.firebase?.appId || '',
};

// Initialize Firebase app
const app = initializeApp(firebaseConfig);

// Initialize Firebase services
const auth = getAuth(app);
const db = getFirestore(app);
const storage = getStorage(app);

// Initialize Firebase Messaging
let messaging: Messaging | null = null;
if (typeof window !== 'undefined') {
  try {
    messaging = getMessaging(app);
  } catch (error) {
    console.warn('Firebase Messaging is not supported in this environment:', error);
  }
}

// Request permission for notifications and get token
const requestNotificationPermission = async (): Promise<string | null> => {
  if (!messaging) {
    console.warn('Messaging is not initialized. Notifications may not work.');
    return null;
  }

  try {
    const token = await getToken(messaging, {
      vapidKey: '<YOUR_PUBLIC_VAPID_KEY>', // Replace with your Firebase VAPID key for web
    });
    console.log('Notification token:', token);
    return token;
  } catch (error) {
    console.error('Error getting notification token:', error);
    return null;
  }
};

// Export the initialized services for use in other parts of the app
export { auth, db, storage, messaging, requestNotificationPermission };
