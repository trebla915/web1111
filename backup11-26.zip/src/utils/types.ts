// frontend/src/utils/types.ts

export type Event = {
  id: string;
  title: string;
  imageUrl: string;
  ticketLink?: string;
  date?: string; // Add date as optional
  flyerUrl?: string; // Add flyerUrl as optional
  status?: string; // Add status as optional
};

// Backend table type for use in backend API interactions
export type BackendTable = {
  id: string; // Unique identification for the table
  number: number; // Table number
  reserved: boolean; // Whether the table is reserved
  reservationId?: string; // Optional reservation ID
  capacity: number; // Capacity of the table
  eventId: string; // Event ID associated with the table
};

// Frontend table type for use in UI rendering
export type FrontendTable = BackendTable & {
  cx?: number; // Optional x-coordinate for SVG layout (for frontend only)
  cy?: number; // Optional y-coordinate for SVG layout (for frontend only)
};

// Unified Table type for use across components
export type Table = FrontendTable;

export type Reservation = {
  id: string;
  eventId: string;
  tableId: string;
  tableNumber: number;
  userId: string;
  reservationTime: string;
  createdAt: string;
  guestCount: number; // Add guestCount to reservation type
};

export type User = {
  id: string; // User ID (UID from Firebase Authentication)
  name: string; // User's full name
  email: string; // User's email address
  phone?: string; // Optional phone number
  reservations?: string[]; // Array of reservation IDs linked to the user
};
