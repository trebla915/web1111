import axios from 'axios';
import { Event, Reservation, Table, User } from './types';
import AsyncStorage from '@react-native-async-storage/async-storage';

// Create an Axios instance
const apiClient = axios.create({
  baseURL: 'https://api-23psv7suga-uc.a.run.app', // Update to your backend URL
  headers: {
    'Content-Type': 'application/json',
  },
});

// Intercept requests to include authentication token
apiClient.interceptors.request.use(
  async (config) => {
    const token = await AsyncStorage.getItem('authToken'); // Retrieve token from AsyncStorage
    if (token) {
      config.headers['Authorization'] = `Bearer ${token}`;
      console.log('Token included in request:', token);
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Intercept responses to handle token refresh or unauthorized cases
apiClient.interceptors.response.use(
  (response) => response,
  async (error) => {
    if (error.response?.status === 401) {
      console.error('Token expired or unauthorized. Attempting refresh...');
      // Implement token refresh logic here if needed
    }
    return Promise.reject(error);
  }
);

// Utility function to log errors
const logError = (error: any, action: string) => {
  console.error(`Error ${action}:`, error.response?.data || error.message);
  throw new Error(`Failed to ${action}. Please try again.`);
};

// Set authentication token
export const setAuthToken = async (token: string | null) => {
  try {
    if (token) {
      await AsyncStorage.setItem('authToken', token);
      apiClient.defaults.headers.common['Authorization'] = `Bearer ${token}`;
      console.log('Auth token set:', token);
    } else {
      await AsyncStorage.removeItem('authToken');
      delete apiClient.defaults.headers.common['Authorization'];
      console.log('Auth token removed.');
    }
  } catch (error) {
    console.error('Error updating token in storage:', error);
  }
};

// Fetch all events
export const fetchEvents = async (): Promise<Event[]> => {
  try {
    const response = await apiClient.get<Event[]>('/events');
    console.log('Fetched events:', response.data);
    return response.data;
  } catch (error: any) {
    logError(error, 'fetch events');
    return [];
  }
};

// Create a new event
export const createEvent = async (eventData: Partial<Event>): Promise<Event> => {
  try {
    console.log('Attempting to create event with data:', eventData);

    const response = await apiClient.post<Event>('/events', eventData);

    console.log('Event created successfully. Backend response:', response.data);
    return response.data;
  } catch (error: any) {
    console.error('Error during event creation. Error details:', {
      message: error.message,
      response: error.response?.data,
      request: error.config,
    });
    throw error; // Ensure the error propagates
  }
};

// Update an existing event
export const updateEvent = async (eventId: string, eventData: Partial<Event>): Promise<Event> => {
  try {
    console.log(`Updating event ${eventId} with data:`, eventData);
    const response = await apiClient.put<Event>(`/events/${eventId}`, eventData);
    console.log('Event updated successfully:', response.data);
    return response.data;
  } catch (error: any) {
    logError(error, 'update event');
    throw error;
  }
};

// Delete an event
export const deleteEvent = async (eventId: string): Promise<void> => {
  try {
    console.log(`Deleting event with ID: ${eventId}`);
    await apiClient.delete(`/events/${eventId}`);
    console.log('Event deleted successfully.');
  } catch (error: any) {
    logError(error, 'delete event');
  }
};

// Create tables for an event
export const createTablesForEvent = async (
  eventId: string,
  numberOfTables: number,
  seatsPerTable: number
): Promise<void> => {
  try {
    console.log(`Creating tables for event ${eventId}`);
    await apiClient.post(`/events/${eventId}/tables`, {
      numberOfTables,
      seatsPerTable,
    });
    console.log('Tables created successfully.');
  } catch (error: any) {
    logError(error, 'create tables for event');
    throw error;
  }
};

// Fetch tables for a specific event
export const fetchTablesForEvent = async (eventId: string): Promise<Table[]> => {
  const response = await apiClient.get<Table[]>(`/tables/${eventId}`);
  return response.data;
};

// Fetch reservations by event
export const fetchReservationsByEvent = async (eventId: string): Promise<Reservation[]> => {
  try {
    const response = await apiClient.get<Reservation[]>(`/reservations/${eventId}`);
    console.log('Fetched reservations:', response.data);
    return response.data;
  } catch (error: any) {
    logError(error, 'fetch reservations by event');
    return [];
  }
};

// Fetch all reservations grouped by event
export const fetchAllReservationsGroupedByEvent = async (): Promise<any> => {
  try {
    const response = await apiClient.get('/reservations');
    console.log('[fetchAllReservationsGroupedByEvent] Response:', response.data);
    return response.data;
  } catch (error: any) {
    console.error('[fetchAllReservationsGroupedByEvent] Error:', error.response?.data || error.message);
    throw error;
  }
};

// Create a reservation
export const createReservation = async (
  eventId: string,
  reservationData: Omit<Reservation, 'id' | 'createdAt'>
): Promise<Reservation> => {
  try {
    console.log('Creating reservation for event:', eventId);
    const response = await apiClient.post<Reservation>(`/reservations/${eventId}`, reservationData);
    console.log('Reservation created successfully:', response.data);
    return response.data;
  } catch (error: any) {
    logError(error, 'create reservation');
    throw error;
  }
};

// Create a new user
export const createUserAPI = async (userData: User): Promise<void> => {
  try {
    console.log('Creating user with data:', userData);
    const response = await apiClient.post('/users', userData);
    console.log('User created successfully:', response.data);
  } catch (error: any) {
    logError(error, 'create user');
    throw error;
  }
};

export { apiClient };
