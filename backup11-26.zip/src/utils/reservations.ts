import { createReservation as createReservationAPI, fetchReservationsByEvent, updateReservation, deleteReservation } from './api';
import { Reservation } from './types';

// Helper function to handle API errors
const handleApiError = (error: any, action: string): never => {
  if (error.response) {
    if (error.response.status === 404) {
      console.warn(`No data found during ${action}.`);
      throw new Error(`No data found during ${action}.`);
    } else if (error.response.status === 403) {
      console.error(`Access denied during ${action}.`);
      throw new Error("Permission denied.");
    }
  }
  console.error(`Error during ${action}:`, error);
  throw new Error(`An error occurred during ${action}.`);
};

// Log the API response
const logResponse = (message: string, data: any) => {
  console.log(`${message}:`, data);
};

// Create a reservation
export const createReservation = async (
  eventId: string,
  reservationData: Omit<Reservation, 'id' | 'createdAt'>
): Promise<Reservation | undefined> => {
  try {
    console.log(`[createReservation] Starting reservation creation with eventId: ${eventId}`);
    console.log('[createReservation] Reservation data:', reservationData);

    const response = await createReservationAPI(eventId, reservationData);
    logResponse("[createReservation] Reservation created successfully", response);

    return response;
  } catch (error) {
    handleApiError(error, "creating reservation");
  }
  return undefined; // Ensure a value is returned in all cases
};

// Fetch all reservations for a specific event
export const getReservationsByEvent = async (
  eventId: string
): Promise<Reservation[] | undefined> => {
  try {
    console.log(`[getReservationsByEvent] Fetching reservations for eventId: ${eventId}`);
    
    const response = await fetchReservationsByEvent(eventId);
    logResponse("[getReservationsByEvent] Event reservations fetched successfully", response);

    return response;
  } catch (error) {
    handleApiError(error, "fetching reservations by event");
  }
  return undefined; // Ensure a value is returned in all cases
};

// Update an existing reservation
export const updateExistingReservation = async (
  eventId: string,
  reservationId: string,
  data: Partial<Reservation>
): Promise<Reservation | undefined> => {
  try {
    console.log(`[updateExistingReservation] Updating reservation with eventId: ${eventId}, reservationId: ${reservationId}`);
    console.log('[updateExistingReservation] Update data:', data);

    const response = await updateReservation(eventId, reservationId, data);
    logResponse("[updateExistingReservation] Reservation updated successfully", response);

    return response;
  } catch (error) {
    handleApiError(error, "updating reservation");
  }
  return undefined; // Ensure a value is returned in all cases
};

// Delete a reservation
export const deleteExistingReservation = async (
  eventId: string,
  reservationId: string
): Promise<void> => {
  try {
    console.log(`[deleteExistingReservation] Deleting reservation with eventId: ${eventId}, reservationId: ${reservationId}`);

    await deleteReservation(eventId, reservationId);
    console.log("[deleteExistingReservation] Reservation deleted successfully");
  } catch (error) {
    handleApiError(error, "deleting reservation");
  }
};
