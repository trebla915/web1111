import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { storage } from '../config/firebaseConfig';
import {
  fetchEvents,
  createEvent,
  updateEvent,
  deleteEvent,
  createTablesForEvent,
} from './api';
import { Event } from './types';

/**
 * Helper function to infer MIME type based on file extension.
 * @param {string} uri - The URI of the file.
 * @returns {string} - The inferred MIME type.
 */
const getMimeType = (uri: string): string => {
  const extension = uri.split('.').pop()?.toLowerCase();
  switch (extension) {
    case 'jpg':
    case 'jpeg':
      return 'image/jpeg';
    case 'png':
      return 'image/png';
    case 'gif':
      return 'image/gif';
    default:
      return 'application/octet-stream';
  }
};

/**
 * Uploads an image to Firebase Storage and returns its download URL.
 * @param {string} uri - The local file URI of the image to upload.
 * @param {string} path - The path in Firebase Storage where the image will be stored.
 * @returns {Promise<string>} - The public download URL of the uploaded file.
 */
export const uploadImageToStorage = async (uri: string, path: string): Promise<string> => {
  try {
    console.log(`Uploading file from URI: ${uri}`);
    const response = await fetch(uri);
    const blob = await response.blob();
    console.log('Blob created:', blob);

    const storageRef = ref(storage, path);
    await uploadBytes(storageRef, blob, { contentType: getMimeType(uri) });
    console.log('File uploaded successfully.');

    const url = await getDownloadURL(storageRef);
    console.log("File uploaded successfully. Public URL:", url);
    return url;
  } catch (error: any) {
    console.error("Error during file upload:", error);
    throw error;
  }
};

/**
 * Logs API responses for debugging purposes.
 * @param {string} message - The log message.
 * @param {any} data - The data to log.
 */
export const logResponse = (message: string, data: any) => {
  console.log(`${message}:`, data);
};

/**
 * Handles API errors by logging and re-throwing them.
 * @param {any} error - The error object.
 * @param {string} action - The action being performed when the error occurred.
 */
export const handleApiError = (error: any, action: string) => {
  if (error.response) {
    const { status, data } = error.response;
    console.error(`Error during ${action}:`, status, data || error.message);
    throw new Error(data?.message || error.message);
  }
  console.error(`Unhandled error during ${action}:`, error.message || error);
  throw error;
};

/**
 * Sanitizes event data by removing unnecessary fields and trimming values.
 * @param {Partial<Event>} eventData - The raw event data to sanitize.
 * @returns {Partial<Event>} - The sanitized event data.
 */
const sanitizeEventData = (eventData: Partial<Event>): Partial<Event> => {
  const sanitizedData: Partial<Event> = {
    title: eventData.title?.trim(),
    imageUrl: eventData.imageUrl?.trim(),
    ticketLink: eventData.ticketLink?.trim(),
    status: eventData.status?.trim() || "active",
    date: eventData.date?.trim(),
    flyerUrl: eventData.flyerUrl?.trim(),
  };

  // Remove undefined or null values
  return Object.fromEntries(
    Object.entries(sanitizedData).filter(([_, value]) => value != null)
  ) as Partial<Event>;
};

/**
 * Creates a new event and initializes tables for it.
 * @param {Omit<Event, 'id'>} eventData - Event data excluding the ID.
 * @param {string} [flyerUri] - Optional URI of the flyer image to be uploaded.
 * @returns {Promise<Event>} - The created event data.
 */
export const createNewEvent = async (
  eventData: Omit<Event, "id">,
  flyerUri?: string
): Promise<Event> => {
  try {
    let imageUrl: string | undefined;

    if (flyerUri) {
      console.log("flyerUri:", flyerUri);
      const timestamp = new Date().toISOString();
      const fileExtension = flyerUri.split('.').pop();
      const fileName = `flyers/${eventData.title}_${timestamp}.${fileExtension}`;
      imageUrl = await uploadImageToStorage(flyerUri, fileName);
      console.log("Flyer uploaded to:", imageUrl);
    }

    if (!eventData.title) {
      throw new Error("Title is required.");
    }

    const sanitizedEventData = sanitizeEventData({ ...eventData, imageUrl });
    const newEvent = await createEvent(sanitizedEventData);

    logResponse("Event created successfully", newEvent);

    if (newEvent.id) {
      try {
        await createTablesForEvent(newEvent.id, 20, 4);
        console.log("Tables created successfully for event:", newEvent.id);
      } catch (tableError: any) {
        console.error("Failed to create tables:", tableError.message || tableError);
      }
    }

    return newEvent;
  } catch (error: any) {
    handleApiError(error, "creating event and initializing tables");
    throw error;
  }
};

/**
 * Fetches all events.
 * @returns {Promise<Event[]>} - List of all events.
 */
export const fetchAllEvents = async (): Promise<Event[]> => {
  try {
    const response = await fetchEvents();
    logResponse("Events fetched successfully", response);
    return response ?? [];
  } catch (error) {
    handleApiError(error, "fetching events");
    throw error;
  }
};

/**
 * Updates an existing event.
 * @param {string} eventId - The ID of the event to update.
 * @param {Partial<Event>} eventData - The partial event data to update.
 * @returns {Promise<Event>} - The updated event data.
 */
export const updateExistingEvent = async (eventId: string, eventData: Partial<Event>): Promise<Event> => {
  try {
    const sanitizedEventData = sanitizeEventData(eventData);
    const response = await updateEvent(eventId, sanitizedEventData);
    logResponse("Event updated successfully", response);
    return response;
  } catch (error) {
    handleApiError(error, "updating event");
    throw error;
  }
};

/**
 * Deletes an event by ID.
 * @param {string} eventId - The ID of the event to delete.
 * @returns {Promise<void>} - Resolves on successful deletion.
 */
export const deleteEventById = async (eventId: string): Promise<void> => {
  try {
    await deleteEvent(eventId);
    console.log("Event deleted successfully");
  } catch (error) {
    handleApiError(error, "deleting event");
    throw error;
  }
};

// Export `createTablesForEvent` alongside other functions
export { createTablesForEvent };
