import React, { createContext, useContext, useState, useEffect } from 'react';
import { getFirestore, doc, getDoc } from 'firebase/firestore';
import { useAuth } from './AuthContext';
import { db } from '../config/firebaseConfig';

interface UserData {
  id: string;
  email: string;
  name?: string;
}

interface ReservationDetails {
  eventId: string;
  tableId: string;
  guestCount: number;
  tableNumber?: number;
}

interface UserContextType {
  userData: UserData | null;
  isLoading: boolean;
  reservationDetails: ReservationDetails | null;
  setReservationDetails: (details: ReservationDetails) => void;
  clearReservationDetails: () => void;
}

const UserContext = createContext<UserContextType | undefined>(undefined);

export const useUser = (): UserContextType => {
  const context = useContext(UserContext);
  if (!context) {
    throw new Error('useUser must be used within a UserProvider');
  }
  return context;
};

export const UserProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [state, setState] = useState<{
    userData: UserData | null;
    isLoading: boolean;
    reservationDetails: ReservationDetails | null;
  }>({
    userData: null,
    isLoading: true,
    reservationDetails: null,
  });

  const { firebaseUser } = useAuth();

  useEffect(() => {
    if (!firebaseUser) {
      setState((prev) => ({
        ...prev,
        userData: null,
        isLoading: false,
      }));
      return;
    }

    const fetchUserData = async () => {
      try {
        setState((prev) => ({ ...prev, isLoading: true }));

        const userDocRef = doc(db, 'users', firebaseUser.uid);
        const userDoc = await getDoc(userDocRef);

        if (userDoc.exists()) {
          setState((prev) => ({
            ...prev,
            userData: {
              id: userDoc.id,
              email: userDoc.data()?.email,
              name: userDoc.data()?.name || '',
            },
            isLoading: false,
          }));
        } else {
          console.warn('No user data found in Firestore');
          setState((prev) => ({
            ...prev,
            userData: null,
            isLoading: false,
          }));
        }
      } catch (error) {
        console.error('Error fetching user data:', error);
        setState((prev) => ({
          ...prev,
          userData: null,
          isLoading: false,
        }));
      }
    };

    fetchUserData();
  }, [firebaseUser]);

  const setReservationDetails = (details: ReservationDetails) => {
    setState((prev) => ({ ...prev, reservationDetails: details }));
  };

  const clearReservationDetails = () => {
    setState((prev) => ({ ...prev, reservationDetails: null }));
  };

  return (
    <UserContext.Provider
      value={{
        userData: state.userData,
        isLoading: state.isLoading,
        reservationDetails: state.reservationDetails,
        setReservationDetails,
        clearReservationDetails,
      }}
    >
      {children}
    </UserContext.Provider>
  );
};
