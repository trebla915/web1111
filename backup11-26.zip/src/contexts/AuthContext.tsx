// frontend/src/contexts/AuthContext.ts

import React, { createContext, useContext, useState, useEffect } from 'react';
import { Alert } from 'react-native';
import {
  getAuth,
  onAuthStateChanged,
  signInWithEmailAndPassword,
  signOut,
  User,
  createUserWithEmailAndPassword,
} from 'firebase/auth';
import { setAuthToken, createUserAPI } from '../utils/api';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { auth } from '../config/firebaseConfig';

interface AuthContextType {
  firebaseUser: User | null;
  userId: string | null;
  isLoading: boolean;
  signIn: (email: string, password: string) => Promise<void>;
  signOut: () => Promise<void>;
  signUp: (email: string, password: string, name: string) => Promise<void>;
  token: string | null;
  refreshAuthToken: () => Promise<string | null>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [authState, setAuthState] = useState<{
    firebaseUser: User | null;
    userId: string | null;
    token: string | null;
    isLoading: boolean;
  }>({
    firebaseUser: null,
    userId: null,
    token: null,
    isLoading: true,
  });

  const updateToken = async (token: string | null) => {
    try {
      if (token) {
        await AsyncStorage.setItem('userToken', token);
        setAuthToken(token);
      } else {
        await AsyncStorage.removeItem('userToken');
        setAuthToken(null);
      }
      setAuthState((prev) => ({ ...prev, token }));
    } catch (error) {
      console.error('Error updating token in storage:', error);
    }
  };

  const refreshAuthToken = async (): Promise<string | null> => {
    try {
      const currentUser = auth.currentUser;
      if (!currentUser) return null;

      const newToken = await currentUser.getIdToken(true);
      await updateToken(newToken);
      console.log('Token refreshed successfully:', newToken);
      return newToken;
    } catch (error: any) {
      console.error('Error refreshing token:', error.message || error);
      Alert.alert('Error', 'Unable to refresh session. Please sign in again.');
      return null;
    }
  };

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setAuthState((prev) => ({ ...prev, isLoading: true }));

      if (user) {
        try {
          const token = await user.getIdToken();
          await updateToken(token);
          setAuthState({
            firebaseUser: user,
            userId: user.uid,
            token,
            isLoading: false,
          });
        } catch (error) {
          console.error('Error during authentication:', error);
          await updateToken(null);
          setAuthState({
            firebaseUser: null,
            userId: null,
            token: null,
            isLoading: false,
          });
        }
      } else {
        await updateToken(null);
        setAuthState({
          firebaseUser: null,
          userId: null,
          token: null,
          isLoading: false,
        });
      }
    });

    return () => unsubscribe();
  }, []);

  const signIn = async (email: string, password: string) => {
    setAuthState((prev) => ({ ...prev, isLoading: true }));
    try {
      const userCredential = await signInWithEmailAndPassword(auth, email, password);
      const token = await userCredential.user.getIdToken();
      await updateToken(token);

      setAuthState({
        firebaseUser: userCredential.user,
        userId: userCredential.user.uid,
        token,
        isLoading: false,
      });
    } catch (error: any) {
      console.error('Sign-in failed:', error.message || error);
      Alert.alert('Error', 'Invalid email or password. Please try again.');
      setAuthState((prev) => ({ ...prev, isLoading: false }));
    }
  };

  const signUp = async (email: string, password: string, name: string) => {
    setAuthState((prev) => ({ ...prev, isLoading: true }));
    try {
      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      const token = await userCredential.user.getIdToken();

      await createUserAPI({
        id: userCredential.user.uid,
        email,
        name,
      });

      await updateToken(token);
      setAuthState({
        firebaseUser: userCredential.user,
        userId: userCredential.user.uid,
        token,
        isLoading: false,
      });
    } catch (error: any) {
      console.error('Sign-up failed:', error.message || error);
      Alert.alert('Error', 'Unable to create an account. Please try again.');
      setAuthState((prev) => ({ ...prev, isLoading: false }));
    }
  };

  const signOutUser = async () => {
    setAuthState((prev) => ({ ...prev, isLoading: true }));
    try {
      await signOut(auth);
      await updateToken(null);
      setAuthState({
        firebaseUser: null,
        userId: null,
        token: null,
        isLoading: false,
      });
    } catch (error: any) {
      console.error('Sign-out failed:', error.message || error);
      Alert.alert('Error', 'Unable to sign out. Please try again.');
      setAuthState((prev) => ({ ...prev, isLoading: false }));
    }
  };

  return (
    <AuthContext.Provider
      value={{
        firebaseUser: authState.firebaseUser,
        userId: authState.userId,
        isLoading: authState.isLoading,
        signIn,
        signOut: signOutUser,
        signUp,
        token: authState.token,
        refreshAuthToken,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
